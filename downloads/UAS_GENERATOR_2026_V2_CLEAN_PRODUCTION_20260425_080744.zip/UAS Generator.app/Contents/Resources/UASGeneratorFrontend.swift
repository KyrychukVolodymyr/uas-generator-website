import SwiftUI
import Foundation
import AppKit

struct OwnerProfile: Codable {
    var first_name: String
    var last_name: String
    var display_name: String
    var email: String
    var accepted_terms_version: String
    var accepted_at: String
    var updated_at: String
}

@main
struct UASGeneratorFrontendApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(.automatic)
    }
}

struct ContentView: View {
    @State private var onboardingComplete: Bool = false
    @State private var onboardingError: String = ""
    @State private var firstName: String = ""
    @State private var lastName: String = ""
    @State private var displayName: String = ""
    @State private var email: String = ""
    @State private var licenseKey: String = ""
    @State private var acceptedTerms: Bool = false

    @State private var csvPath: String = ""
    @State private var patientId: String = ""
    @State private var outputFolder: String = ""
    @State private var daysPerWeek: String = ""
    @State private var hoursPerDay: String = ""
    @State private var bedroomsCount: String = ""
    @State private var accessibleHome: String = "no"

    @State private var cane: Bool = false
    @State private var walker: Bool = false
    @State private var wheelchair: Bool = false
    @State private var hospitalBed: Bool = false
    @State private var grabBar: Bool = false
    @State private var bedsideCommode: Bool = false
    @State private var oxygenInUse: Bool = false
    @State private var hoyerLift: Bool = false
    @State private var raisedToiletSeat: Bool = false
    @State private var showerChair: Bool = false

    @State private var catheter: Bool = false
    @State private var service: Bool = false

    @State private var cdpasAspirationPrecautions: Bool = false
    @State private var cdpasTubeFeeding: Bool = false
    @State private var cdpasOxygenCare: Bool = false
    @State private var cdpasCatheterType: String = ""

    @State private var dwellingType: String = "apartment_elevator"
    @State private var logText: String = "Ready."
    @State private var isRunning: Bool = false
    @State private var preflightComplete: Bool = false
    @State private var systemCheckStatus: String = ""
    @State private var systemCheckPassed: Bool = false

    private var systemCheckButtonFill: Color {
        let s = systemCheckStatus.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if isRunning { return .orange }
        if systemCheckPassed || s.contains("passed") || s.contains("ready=true") || s.contains("ok") {
            return .green
        }
        if s.contains("failed") || s.contains("error") || s.contains("missing") || s.contains("not found") || s.contains("not reachable") {
            return .red
        }
        return .orange
    }

    private var systemCheckStatusColor: Color {
        let s = systemCheckStatus.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if systemCheckPassed || s.contains("passed") || s.contains("ready=true") || s.contains("ok") {
            return .green
        }
        if s.contains("failed") || s.contains("error") || s.contains("missing") || s.contains("not found") || s.contains("not reachable") {
            return .red
        }
        return .secondary
    }


    
    
    func openSupportReport() {
        let base = appBaseDir()
        let txtPath = (base as NSString).appendingPathComponent("support_report.txt")
        let jsonPath = (base as NSString).appendingPathComponent("support_report.json")

        if FileManager.default.fileExists(atPath: txtPath) {
            NSWorkspace.shared.open(URL(fileURLWithPath: txtPath))
            return
        }

        if FileManager.default.fileExists(atPath: jsonPath) {
            NSWorkspace.shared.open(URL(fileURLWithPath: jsonPath))
            return
        }

        let alert = NSAlert()
        alert.messageText = "Support Report Not Found"
        alert.informativeText = "Run System Check first. That will create support_report.txt and support_report.json."
        alert.alertStyle = .warning
        alert.runModal()
    }

func runSystemCheck() {
        isRunning = true
        systemCheckPassed = false
        systemCheckStatus = "Running System Check..."
        logText = "Running System Check..."

        DispatchQueue.global(qos: .userInitiated).async {
            let process = Process()
            let stdoutPipe = Pipe()
            let stderrPipe = Pipe()

            process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
            process.arguments = ["python3", "system_check.py"]
            process.currentDirectoryURL = URL(fileURLWithPath: appBaseDir())
            process.environment = ["PATH": appBaseDir() + "/runtime_venv/bin:/usr/local/bin:/opt/homebrew/bin:/Library/Frameworks/Python.framework/Versions/3.10/bin:/usr/bin:/bin:/usr/sbin:/sbin"]
            process.standardOutput = stdoutPipe
            process.standardError = stderrPipe

            do {
                try process.run()
                process.waitUntilExit()

                let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
                let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()

                let stdoutText = String(data: stdoutData, encoding: .utf8) ?? ""
                let stderrText = String(data: stderrData, encoding: .utf8) ?? ""
                let combined = [stdoutText, stderrText]
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                    .joined(separator: "\n\n")

                let passed = combined.contains("READY=True")

                DispatchQueue.main.async {
                    isRunning = false
                    systemCheckPassed = passed
                    if passed {
                        systemCheckStatus = "System Check passed. You can continue setup."
                    } else {
                        systemCheckStatus = combined.isEmpty ? "System Check failed." : combined
                    }
                    logText = combined.isEmpty ? "System Check finished." : combined
                }
            } catch {
                DispatchQueue.main.async {
                    isRunning = false
                    systemCheckPassed = false
                    let msg = "System Check failed: \(error.localizedDescription)"
                    systemCheckStatus = msg
                    logText = msg
                }
            }
        }
    }

var body: some View {
        Group {
            if !preflightComplete {
                preflightGateView
            } else if onboardingComplete {
                mainGeneratorView
            } else {
                onboardingView
            }
        }
        .onAppear {
            loadOnboardingState()
            preflightComplete = false
        }
    }

    var preflightGateView: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Spacer()
                Button(action: { runSystemCheck() }) {
                    Text("Run System Check")
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .foregroundColor(.white)
                        .background(systemCheckButtonFill)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                .disabled(isRunning)
            }

            Text("System Check Required")
                .font(.title2)
                .bold()

            Text("Before setup or document generation, this application must verify that this Mac can generate all required documents correctly.")
                .foregroundColor(.secondary)

            if !systemCheckStatus.isEmpty {
                Text(systemCheckStatus)
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(systemCheckStatusColor)
            }

            Button("Open Support Report") {
                openSupportReport()
            }
            .disabled(systemCheckStatus.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Button("Continue") {
                preflightComplete = true
            }
            .disabled(!systemCheckPassed || isRunning)

            Text("Continue stays locked until System Check passes.")
                .font(.caption)
                .foregroundColor(.secondary)

            Spacer()
        }
        .padding(16)
        .frame(minWidth: 900, minHeight: 520, alignment: .topLeading)
    }


    var onboardingView: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Spacer()
                Button(action: { runSystemCheck() }) {
                    Text("Run System Check")
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .foregroundColor(.white)
                        .background(systemCheckButtonFill)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                .disabled(isRunning)
            }

            if !systemCheckStatus.isEmpty {
                HStack {
                    Spacer()
                    Text(systemCheckStatus)
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundColor(systemCheckStatusColor)
                        .multilineTextAlignment(.trailing)
                        .lineLimit(2)
                }
            }

            Text("First Launch Setup")
                .font(.title2)
                .bold()

            Text("Before using this application, you must enter your owner identity and accept the Terms of Use.")
                .foregroundColor(.secondary)

            VStack(alignment: .leading, spacing: 8) {
                Text("First name").font(.headline)
                TextField("", text: $firstName)
                    .textFieldStyle(.roundedBorder)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Last name").font(.headline)
                TextField("", text: $lastName)
                    .textFieldStyle(.roundedBorder)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Professional display name").font(.headline)
                TextField("Example: John Smith RN", text: $displayName)
                    .textFieldStyle(.roundedBorder)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Email").font(.headline)
                TextField("", text: $email)
                    .textFieldStyle(.roundedBorder)

                Text("License Key")
                    .frame(maxWidth: .infinity, alignment: .leading)
                TextField("", text: $licenseKey)
                    .textFieldStyle(.roundedBorder)
            }

            HStack(spacing: 12) {
                Button("Open Terms of Use") {
                    openTermsFile()
                }

                Toggle("I accept the Terms of Use", isOn: $acceptedTerms)
                    .toggleStyle(.checkbox)
            }

            if !onboardingError.isEmpty {
                Text(onboardingError)
                    .foregroundColor(.red)
            }

            HStack(spacing: 12) {
                Button("Complete Setup") {
                    completeOnboarding()
                }
                .disabled(
                    !systemCheckPassed ||
                    firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    lastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    !acceptedTerms
                )
            }
        }
        .padding(16)
        .frame(minWidth: 900, minHeight: 520)
    }

    var mainGeneratorView: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Spacer()
                Button(action: {
                    openSupportReport()
                }) {
                    Text("Open Support Report")
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            Text("UAS Generator 2026 V2")
                .font(.title2)
                .bold()

            VStack(alignment: .leading, spacing: 8) {
                Text("CSV file").font(.headline)
                HStack {
                    TextField("Select CSV file", text: $csvPath)
                        .textFieldStyle(.roundedBorder)
                    Button("Browse CSV") { chooseCSV() }
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Patient ID").font(.headline)
                TextField("", text: $patientId)
                    .textFieldStyle(.roundedBorder)
            }

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Days per week").font(.headline)
                    TextField("Example: 5", text: $daysPerWeek)
                        .textFieldStyle(.roundedBorder)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Hours per day").font(.headline)
                    TextField("Example: 6", text: $hoursPerDay)
                        .textFieldStyle(.roundedBorder)
                }
            }

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Number of bedrooms").font(.headline)
                    TextField("2", text: $bedroomsCount)
                        .textFieldStyle(.roundedBorder)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Home accessible for people with disabilities").font(.headline)
                    Picker("Accessible home", selection: $accessibleHome) {
                        Text("No").tag("no")
                        Text("Yes").tag("yes")
                    }
                    .pickerStyle(.segmented)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Dwelling type").font(.headline)
                Picker("Dwelling type", selection: $dwellingType) {
                    Text("House + outside stairs").tag("single_family_outside")
                    Text("House + inside stairs").tag("single_family_inside")
                    Text("Apartment + outside stairs").tag("apartment_outside")
                    Text("Apartment + elevator").tag("apartment_elevator")
                }
                .pickerStyle(.segmented)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Equipment").font(.headline)
                HStack(spacing: 18) {
                    Toggle("Bedside Commode", isOn: $bedsideCommode)
                    Toggle("Cane", isOn: $cane)
                    Toggle("Grab Bar", isOn: $grabBar)
                    Toggle("Hospital Bed", isOn: $hospitalBed)
                    Toggle("Hoyer Lift", isOn: $hoyerLift)
                }
                HStack(spacing: 18) {
                    Toggle("Oxygen", isOn: $oxygenInUse)
                    Toggle("Raised Toilet Seat", isOn: $raisedToiletSeat)
                    Toggle("Shower Chair", isOn: $showerChair)
                    Toggle("Walker", isOn: $walker)
                    Toggle("Wheelchair", isOn: $wheelchair)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Other app options").font(.headline)
                HStack(spacing: 18) {
                    Toggle("Service", isOn: $service)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("CDPAS Controls").font(.headline)
                HStack(spacing: 18) {
                    Toggle("Aspiration Precautions", isOn: $cdpasAspirationPrecautions)
                    Toggle("Tube Feeding", isOn: $cdpasTubeFeeding)
                    Toggle("Oxygen Care", isOn: $cdpasOxygenCare)
                }
                HStack(spacing: 12) {
                    Picker("Catheter Type", selection: $cdpasCatheterType) {
                        Text("None").tag("")
                        Text("Suprapubic").tag("Suprapubic")
                        Text("Foley/Indwelling").tag("Foley/Indwelling")
                        Text("Texas/Condom").tag("Texas/Condom")
                        Text("Straight Cath").tag("Straight Cath")
                    }
                    .pickerStyle(.menu)
                    Spacer()
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Output folder").font(.headline)
                HStack {
                    TextField("Choose output folder or leave existing saved one", text: $outputFolder)
                        .textFieldStyle(.roundedBorder)
                    Button("Browse Folder") { chooseFolder() }
                }
            }

            HStack(spacing: 12) {
                Button(isRunning ? "Generating..." : "Generate Files") {
                    runGenerator()
                }
                .disabled(
                    isRunning ||
                    csvPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                )

                Button("Clear Log") {
                    logText = "Ready."
                }
                .disabled(isRunning)
            }

            HStack {
                Text("Log").font(.headline)
                Spacer()
                Button(action: {
                    openSupportReport()
                }) {
                    Text("Open Support Report")
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            TextEditor(text: $logText)
                .font(.system(.body, design: .monospaced))
                .frame(minHeight: 260)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.35), lineWidth: 1)
                )
        }
        .padding(16)
        .frame(minWidth: 1180, minHeight: 860)
    }


    func appBaseDir() -> String {
        let fm = FileManager.default
        let supportBase = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let runtimeDir = supportBase.appendingPathComponent("UASGenerator2026V2", isDirectory: true)

        do {
            try fm.createDirectory(at: runtimeDir, withIntermediateDirectories: true)

            if let resourcePath = Bundle.main.resourcePath {
                let resourceURL = URL(fileURLWithPath: resourcePath)
                let items = try fm.contentsOfDirectory(atPath: resourcePath)

                let preserveFiles: Set<String> = [
                    "license.json",
                    "device.json",
                    "user_profile.json",
                    "support_report.json",
                    "support_report.txt",
                    "config.json",
                    "runtime_venv"
                ]

                for item in items {
                    if preserveFiles.contains(item) {
                        continue
                    }

                    let src = resourceURL.appendingPathComponent(item)
                    let dst = runtimeDir.appendingPathComponent(item)

                    if fm.fileExists(atPath: dst.path) {
                        try? fm.removeItem(at: dst)
                    }

                    try? fm.copyItem(at: src, to: dst)
                }

                let configSrc = resourceURL.appendingPathComponent("config.json")
                let configDst = runtimeDir.appendingPathComponent("config.json")
                if !fm.fileExists(atPath: configDst.path) && fm.fileExists(atPath: configSrc.path) {
                    try? fm.copyItem(at: configSrc, to: configDst)
                }
            }
        } catch {
            return runtimeDir.path
        }

        return runtimeDir.path
    }


    func termsPath() -> String {
        return (appBaseDir() as NSString).appendingPathComponent("Terms_of_Use.txt")
    }

    func profilePath() -> String {
        return (appBaseDir() as NSString).appendingPathComponent("user_profile.json")
    }

    func licenseTextPath() -> String {
        return (appBaseDir() as NSString).appendingPathComponent("LICENSE.txt")
    }

    func ensureStaticCommercialFiles() {
        let fm = FileManager.default

        let terms = termsPath()
        if !fm.fileExists(atPath: terms) {
            let text = """
Anthem BCBS Doc Generator - Terms of Use
Version: 2026-04-19-v1

1. This software is an assistive documentation tool only.
2. The software may generate incomplete, inaccurate, or unsuitable output.
3. The user must independently review, verify, and confirm every generated document before use, signature, or submission.
4. The user bears sole responsibility for any signed, submitted, relied-upon, or distributed documentation.
5. The software is provided as-is, without warranties of completeness, accuracy, merchantability, or fitness for a particular purpose.
6. Reverse engineering, redistribution, sublicensing, resale, decompilation, key sharing, and unauthorized copying are prohibited.
7. Licenses are personal, limited, revocable, and non-transferable.
8. No refunds are provided.
9. Generated outputs are stored locally under the user's control.
10. Only license/account metadata may be stored remotely for activation, validation, support, and updates.
"""
            try? text.write(toFile: terms, atomically: true, encoding: .utf8)
        }

        let lic = licenseTextPath()
        if !fm.fileExists(atPath: lic) {
            let text = """
Anthem BCBS Doc Generator - License Summary

This software is licensed, not sold.
Basic plan: 1 device maximum.
Pro plan: up to 2 devices maximum, same named user only.
All licenses are non-transferable and may be revoked for misuse, key sharing, reverse engineering, redistribution, or non-payment.
"""
            try? text.write(toFile: lic, atomically: true, encoding: .utf8)
        }
    }

    func loadOnboardingState() {
        ensureStaticCommercialFiles()

        let fm = FileManager.default
        let profile = profilePath()
        let license = (appBaseDir() as NSString).appendingPathComponent("license.json")
        let device = (appBaseDir() as NSString).appendingPathComponent("device.json")

        guard fm.fileExists(atPath: profile),
              fm.fileExists(atPath: license),
              fm.fileExists(atPath: device) else {
            onboardingComplete = false
            return
        }

        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: profile))
            let profileObj = try JSONDecoder().decode(OwnerProfile.self, from: data)
            firstName = profileObj.first_name
            lastName = profileObj.last_name
            displayName = profileObj.display_name
            email = profileObj.email
            acceptedTerms = true
            onboardingComplete = true
        } catch {
            onboardingComplete = false
            onboardingError = "Could not read existing owner profile."
        }
    }

    func openTermsFile() {
        ensureStaticCommercialFiles()
        NSWorkspace.shared.open(URL(fileURLWithPath: termsPath()))
    }

    func activateLicenseKeyFromUI(_ key: String) throws {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            throw NSError(domain: "LicenseActivation", code: 1, userInfo: [NSLocalizedDescriptionKey: "License key is required."])
        }

        let process = Process()
        let stdoutPipe = Pipe()
        let stderrPipe = Pipe()

        process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        process.arguments = ["python3", "activate_license.py", "--key", trimmed, "--email", email.trimmingCharacters(in: .whitespacesAndNewlines), "--terms-version", "2026-04-21-v2", "--app-version", "v1"]
        process.currentDirectoryURL = URL(fileURLWithPath: appBaseDir())
            process.environment = ["PATH": appBaseDir() + "/runtime_venv/bin:/usr/local/bin:/opt/homebrew/bin:/Library/Frameworks/Python.framework/Versions/3.10/bin:/usr/bin:/bin:/usr/sbin:/sbin"]
        process.standardOutput = stdoutPipe
        process.standardError = stderrPipe

        try process.run()
        process.waitUntilExit()

        let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
        let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()

        let stdoutText = String(data: stdoutData, encoding: .utf8) ?? ""
        let stderrText = String(data: stderrData, encoding: .utf8) ?? ""
        let combined = ([stdoutText, stderrText]
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: "\n"))

        if process.terminationStatus != 0 {
            throw NSError(
                domain: "LicenseActivation",
                code: Int(process.terminationStatus),
                userInfo: [NSLocalizedDescriptionKey: combined.isEmpty ? "License activation failed." : combined]
            )
        }
    }



    func completeOnboarding() {
        do {
            try activateLicenseKeyFromUI(licenseKey)
        } catch {
            let alert = NSAlert()
            alert.messageText = "License Activation Failed"
            alert.informativeText = error.localizedDescription
            alert.alertStyle = .warning
            alert.runModal()
            return
        }

        onboardingError = ""
        ensureStaticCommercialFiles()

        let now = ISO8601DateFormatter().string(from: Date())
        let cleanFirst = firstName.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanLast = lastName.trimmingCharacters(in: .whitespacesAndNewlines)
        let rawDisplay = displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        let badDisplayValues = ["", "RN", "LPN", "NP", "PA", "BSN", "MSN", "DNP"]
        let finalDisplayName = badDisplayValues.contains(rawDisplay.uppercased()) ? "\(cleanFirst) \(cleanLast) RN".trimmingCharacters(in: .whitespacesAndNewlines) : rawDisplay

        let profile = OwnerProfile(
            first_name: cleanFirst,
            last_name: cleanLast,
            display_name: finalDisplayName,
            email: email.trimmingCharacters(in: .whitespacesAndNewlines),
            accepted_terms_version: "2026-04-21-v2",
            accepted_at: now,
            updated_at: now
        )

        do {
            let data = try JSONEncoder().encode(profile)
            try data.write(to: URL(fileURLWithPath: profilePath()))
            onboardingComplete = true
        } catch {
            onboardingError = "Could not save owner profile."
        }
    }

    func chooseCSV() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.commaSeparatedText, .text]
        if panel.runModal() == .OK {
            csvPath = panel.url?.path ?? ""
        }
    }

    func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK {
            outputFolder = panel.url?.path ?? ""
        }
    }

    func shellEscape(_ value: String) -> String {
        return "'" + value.replacingOccurrences(of: "'", with: "'\"'\"'") + "'"
    }

    func resetPatientEntryFields() {
        patientId = ""
        daysPerWeek = ""
        hoursPerDay = ""
        bedroomsCount = ""
        accessibleHome = "no"

        cane = false
        walker = false
        wheelchair = false
        hospitalBed = false
        grabBar = false
        bedsideCommode = false
        oxygenInUse = false
        hoyerLift = false
        raisedToiletSeat = false
        showerChair = false

        catheter = false
        service = false

        cdpasAspirationPrecautions = false
        cdpasTubeFeeding = false
        cdpasOxygenCare = false
        cdpasCatheterType = ""

        dwellingType = "apartment_elevator"
    }

    func runGenerator() {
        isRunning = true
        logText = "Running..."

        DispatchQueue.global(qos: .userInitiated).async {
            let executablePath = CommandLine.arguments[0]
            let executableURL = URL(fileURLWithPath: executablePath).resolvingSymlinksInPath()
            let macOSDir = executableURL.deletingLastPathComponent()
            let contentsDir = macOSDir.deletingLastPathComponent()
            let appBundleDir = contentsDir.deletingLastPathComponent()
            let baseDir = appBundleDir.deletingLastPathComponent().path
            let scriptPath = (baseDir as NSString).appendingPathComponent("app_mac.py")

            var pieces: [String] = []
            pieces.append("python3 " + shellEscape(scriptPath))
            pieces.append("--csv " + shellEscape(csvPath))
            pieces.append("--no-dialogs")

            let trimmedPatientId = patientId.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedPatientId.isEmpty {
                pieces.append("--patient " + shellEscape(trimmedPatientId))
            }

            let trimmedOutput = outputFolder.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedOutput.isEmpty {
                pieces.append("--output " + shellEscape(trimmedOutput))
            }

            let trimmedDays = daysPerWeek.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedDays.isEmpty {
                pieces.append("--days-per-week " + shellEscape(trimmedDays))
            }

            let trimmedHours = hoursPerDay.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedHours.isEmpty {
                pieces.append("--hours-per-day " + shellEscape(trimmedHours))
            }

            let trimmedBedrooms = bedroomsCount.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedBedrooms.isEmpty {
                pieces.append("--bedrooms-count " + shellEscape(trimmedBedrooms))
            }

            pieces.append("--accessible-home " + shellEscape(accessibleHome))
            pieces.append("--dwelling-type " + shellEscape(dwellingType))

            if bedsideCommode { pieces.append("--bedside-commode") }
            if cane { pieces.append("--cane") }
            if grabBar { pieces.append("--grab-bar") }
            if hospitalBed { pieces.append("--hospital-bed") }
            if hoyerLift { pieces.append("--hoyer-lift") }
            if oxygenInUse { pieces.append("--oxygen-in-use") }
            if raisedToiletSeat { pieces.append("--raised-toilet-seat") }
            if showerChair { pieces.append("--shower-chair") }
            if walker { pieces.append("--walker") }
            if wheelchair { pieces.append("--wheelchair") }

            if cdpasAspirationPrecautions { pieces.append("--cdpas-aspiration-precautions") }
            if cdpasTubeFeeding { pieces.append("--cdpas-tube-feeding") }
            if cdpasOxygenCare { pieces.append("--cdpas-oxygen-care") }
            let trimmedCatheterType = cdpasCatheterType.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedCatheterType.isEmpty {
                pieces.append("--cdpas-catheter-type " + shellEscape(trimmedCatheterType))
            }

            if catheter { pieces.append("--catheter") }
            if service { pieces.append("--service") }

            let command = "cd " + shellEscape(baseDir) + " && " + pieces.joined(separator: " ")

            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/bin/zsh")
            process.arguments = ["-lc", command]

            let stdout = Pipe()
            let stderr = Pipe()
            process.standardOutput = stdout
            process.standardError = stderr

            do {
                try process.run()
                process.waitUntilExit()

                let outData = stdout.fileHandleForReading.readDataToEndOfFile()
                let errData = stderr.fileHandleForReading.readDataToEndOfFile()

                let outText = String(data: outData, encoding: .utf8) ?? ""
                let errText = String(data: errData, encoding: .utf8) ?? ""

                DispatchQueue.main.async {
                    isRunning = false
                    if process.terminationStatus == 0 {
                        logText = outText.isEmpty ? "Done." : outText
                        resetPatientEntryFields()
                    } else {
                        logText = errText.isEmpty ? "Generation failed." : errText
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    isRunning = false
                    logText = "Failed to start: \(error.localizedDescription)"
                }
            }
        }
    }
}
