from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
VENV_DIR = APP_DIR / ".venv"
REQ_FILE = APP_DIR / "requirements.txt"

def run_osascript(script: str):
    p = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()

def ask_user_to_install() -> bool:
    script = '''
    tell application "System Events"
        activate
        set b to button returned of (display dialog "This app needs to install its local Python runtime the first time it runs. Install now?" buttons {"Cancel", "Install"} default button "Install" with icon note)
        return b
    end tell
    '''
    code, out, err = run_osascript(script)
    return code == 0 and out == "Install"

def show_message(msg: str):
    safe = msg.replace("\\", "\\\\").replace('"', '\\"')
    script = f'''
    tell application "System Events"
        activate
        display dialog "{safe}" buttons {{"OK"}} default button "OK" with icon note
    end tell
    '''
    run_osascript(script)

def show_error(msg: str):
    safe = msg.replace("\\", "\\\\").replace('"', '\\"')
    script = f'''
    tell application "System Events"
        activate
        display dialog "{safe}" buttons {{"OK"}} default button "OK" with icon stop
    end tell
    '''
    run_osascript(script)

def venv_python() -> Path:
    return VENV_DIR / "bin" / "python3"

def ensure_venv():
    py = venv_python()
    if py.exists():
        return py

    if not ask_user_to_install():
        raise SystemExit(1)

    subprocess.run([sys.executable, "-m", "venv", str(VENV_DIR)], check=True)
    py = venv_python()
    subprocess.run([str(py), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=True)
    subprocess.run([str(py), "-m", "pip", "install", "-r", str(REQ_FILE)], check=True)
    show_message("Local runtime installed successfully.")
    return py

def ensure_requirements(py: Path):
    check_code = """
import importlib, sys
mods = ["pandas","openpyxl","pypdf","PyPDF2","reportlab"]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
print("\\n".join(missing))
sys.exit(1 if missing else 0)
"""
    p = subprocess.run([str(py), "-c", check_code], capture_output=True, text=True)
    if p.returncode == 0:
        return
    missing = [x.strip() for x in (p.stdout or "").splitlines() if x.strip()]
    if not ask_user_to_install():
        raise SystemExit(1)
    subprocess.run([str(py), "-m", "pip", "install", "-r", str(REQ_FILE)], check=True)
    if missing:
        show_message("Installed missing packages: " + ", ".join(missing))

def main():
    try:
        py = ensure_venv()
        ensure_requirements(py)
        cmd = [str(py), str(APP_DIR / "app_mac.py"), *sys.argv[1:]]
        os.execv(str(py), cmd)
    except subprocess.CalledProcessError as e:
        show_error(f"Runtime setup failed.\\n\\nCommand: {' '.join(map(str, e.cmd))}\\nExit code: {e.returncode}")
        raise SystemExit(1)
    except Exception as e:
        show_error(f"Runtime setup failed.\\n\\n{e}")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
