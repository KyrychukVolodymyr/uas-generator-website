
def strip_excel_comments_vml_parts(xlsx_path):
    """MAC_V20_PATCH6_STRIP_TT_VML: remove comments/VML parts that trigger Excel repair warnings."""
    import zipfile
    import tempfile
    import shutil
    import re
    from pathlib import Path

    xlsx_path = Path(xlsx_path)
    if not xlsx_path.exists():
        return

    tmp = Path(tempfile.mktemp(suffix=".xlsx"))

    remove_name_patterns = (
        "/comments/",
        "comments/comment",
        "vmldrawing",
        "vmlDrawing",
    )

    try:
        with zipfile.ZipFile(xlsx_path, "r") as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                name = item.filename
                lower = name.lower()

                if any(p.lower() in lower for p in remove_name_patterns):
                    continue

                data = zin.read(name)

                if name.endswith(".rels"):
                    try:
                        txt = data.decode("utf-8")
                        txt = re.sub(r'<Relationship[^>]+Target="[^"]*(?:comments|vmlDrawing|vmldrawing)[^"]*"[^>]*/>', '', txt)
                        data = txt.encode("utf-8")
                    except Exception:
                        pass

                elif name.endswith(".xml"):
                    try:
                        txt = data.decode("utf-8")
                        txt = re.sub(r'<legacyDrawing[^>]*/>', '', txt)
                        txt = re.sub(r'<legacyDrawingHF[^>]*/>', '', txt)
                        txt = re.sub(r'<Override[^>]+PartName="[^"]*(?:comments|vmlDrawing|vmldrawing)[^"]*"[^>]*/>', '', txt)
                        data = txt.encode("utf-8")
                    except Exception:
                        pass

                zout.writestr(item, data)

        shutil.move(str(tmp), str(xlsx_path))
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except Exception:
                pass


from openpyxl import load_workbook

def _tt_num(value):
    try:
        if value in (None, ""):
            return 0
        return float(value)
    except Exception:
        return 0

def _tt_recalc_sheet(ws):
    """
    Keep TT formulas alive.

    The program still fills CSV-derived input cells in B:H and I:J.
    This function must NOT replace formula cells with hardcoded numbers.
    K12:K26 and K27 stay as Excel formulas so manual edits recalculate.
    """
    for row in range(12, 27):
        ws[f"K{row}"] = f"=SUM(B{row}:H{row})*I{row}*J{row}"

    ws["K27"] = "=ROUND(SUM(K12:K26)/60,0)"  # MAC_V20_PATCH1_TT_WHOLE_HOURS
    ws["K27"].number_format = "0"  # MAC_V20_PATCH3_TT_WHOLE_NUMBER_DISPLAY
    for _r in range(12, 28):  # MAC_V20_PATCH4_FORCE_WORKBOOK_RECALC
        ws[f"K{_r}"].number_format = "0"
    try:
        wb = ws.parent
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
    except Exception:
        pass

    try:
        wb = ws.parent
        wb.calculation.calcMode = "auto"
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except Exception:
        pass

def _rows_blob(rows):
    parts = []
    for row in rows:
        if isinstance(row, (list, tuple)):
            joined = " | ".join(str(c).strip() for c in row if str(c).strip())
        else:
            joined = str(row).strip()
        if joined:
            parts.append(joined.lower())
    return "\n".join(parts)

def _row_has_minutes(ws, row_num):
    for col in ["B", "C", "D", "E", "F", "G", "H"]:
        v = ws[f"{col}{row_num}"].value
        try:
            if v not in (None, "") and float(v) > 0:
                return True
        except Exception:
            pass
    return False

def apply_tt_schedule_override_v2(xlsx_path, days_per_week, hours_per_day, rows, service_flag=False):
    wb = load_workbook(xlsx_path)
    ws = wb.active

    # Row 32 (K32/B32) population is branch-specific: blanked for SCIC, written
    # for Routine. See the is_scic / else branches below.

    footer_days = days_per_week  # MAC_V20_PATCH1_A36_USES_OVERRIDE_NOT_ROW32
    footer_hours = hours_per_day  # MAC_V20_PATCH1_A36_USES_OVERRIDE_NOT_ROW32

    if footer_days not in (None, "") and footer_hours not in (None, ""):
        footer = f"PCA {footer_days} D x {footer_hours} H"
    elif footer_days not in (None, ""):
        footer = f"PCA {footer_days} D"
    else:
        footer = "PCA"

    if service_flag:
        ws["A36"] = footer + "\nWould like to discuss service hrs with CM."
    else:
        ws["A36"] = footer

    blob = _rows_blob(rows)
    is_scic = "significant change in status reassessment" in blob

    if is_scic:
        # SCIC: full-week task pattern is forced; row 32 stays blank (policy).
        ws["B32"] = None  # MAC_V20_PATCH1_KEEP_ROW32_BLANK (SCIC only)
        ws["K32"] = None  # MAC_V20_PATCH1_KEEP_ROW32_BLANK (SCIC only)
        scic_rows = {
            12: 7, 13: 7, 14: 3, 15: 7, 16: 2,
            17: 7, 18: 7, 19: 7, 20: 7, 21: 7,
            22: 7, 23: 7, 24: 7
        }
        for r, v in scic_rows.items():
            ws[f"J{r}"] = v
    else:
        # FIX: Routine reassessment — row 32 carries the entered PCA schedule, and
        # PCA-frequency task rows follow the entered days-per-week. Rows 14 and 16
        # are fixed per-task frequencies (the same exception rows the SCIC map
        # treats specially) and are preserved as the CSV ingest wrote them.
        # Rows 25/26 are handled by the laundry logic below.
        if hours_per_day is not None:
            ws["B32"] = hours_per_day
        if days_per_week is not None:
            ws["K32"] = days_per_week
        if days_per_week is not None:
            rows_to_override = [12, 13, 15, 17, 18, 19, 20, 21, 22, 23, 24]
            for r in rows_to_override:
                ws[f"J{r}"] = days_per_week

    laundry_continent_active = _row_has_minutes(ws, 25)
    laundry_incontinent_active = _row_has_minutes(ws, 26)

    if laundry_incontinent_active:
        ws["J25"] = None
        ws["J26"] = 3
    elif laundry_continent_active:
        ws["J25"] = 2
        ws["J26"] = None
    else:
        ws["J25"] = None
        ws["J26"] = None

    _tt_recalc_sheet(ws)
    for _ws in wb.worksheets:  # MAC_V20_PATCH3_REMOVE_TT_COMMENTS_FOR_EXCEL_COMPAT
        for _row in _ws.iter_rows():
            for _cell in _row:
                if _cell.comment is not None:
                    _cell.comment = None
    wb.save(xlsx_path)
    strip_excel_comments_vml_parts(xlsx_path)  # MAC_V20_PATCH6_STRIP_TT_VML
