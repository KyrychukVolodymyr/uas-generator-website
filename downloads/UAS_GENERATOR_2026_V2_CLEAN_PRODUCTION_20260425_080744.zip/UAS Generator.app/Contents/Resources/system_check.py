from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
import subprocess
import sys
import tempfile
import urllib.request

APP_DIR = Path(__file__).resolve().parent
REPORT_JSON = APP_DIR / "support_report.json"
REPORT_TXT = APP_DIR / "support_report.txt"
VENV_DIR = APP_DIR / "runtime_venv"
VENV_PYTHON = VENV_DIR / "bin" / "python3"

REQUIRED_FILES = [
    "activate_license.py",
    "license_manager.py",
    "generate_outputs.py",
    "app_mac.py",
    "license_server_config.json",
    "config.json",
    "Terms_of_Use.txt",
    "TT_template.xlsx",
    "CDPAS_template.xlsx",
    "FRA_template.pdf",
    "PHQ9_template.pdf",
    "CM_InPerson_Visit_Template.pdf"
]

REQUIRED_MODULES = ["pandas", "openpyxl", "pypdf", "requests", "certifi"]

def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def read_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default

def write_report(report):
    REPORT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = [
        "UAS Generator Support Report",
        f"Created: {report['created_at']}",
        f"Ready: {report['ready']}",
        "",
        "Problems:"
    ]
    lines += [f"- {x}" for x in report["problems"]]
    lines += ["", "Warnings:"]
    lines += [f"- {x}" for x in report["warnings"]]
    lines += ["", "Environment:"]
    for k, v in report["environment"].items():
        lines.append(f"- {k}: {v}")
    REPORT_TXT.write_text("\n".join(lines), encoding="utf-8")

def run(cmd, timeout=300):
    return subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)

def ensure_venv(problems, warnings):
    if not VENV_PYTHON.exists():
        r = run([sys.executable, "-m", "venv", str(VENV_DIR)], timeout=300)
        if r.returncode != 0:
            problems.append("Could not create runtime Python venv: " + (r.stderr or r.stdout))
            return

    r = run([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], timeout=300)
    if r.returncode != 0:
        warnings.append("Could not upgrade pip: " + (r.stderr or r.stdout))

    r = run([str(VENV_PYTHON), "-m", "pip", "install", "pandas", "openpyxl", "pypdf", "requests", "certifi"], timeout=900)
    if r.returncode != 0:
        problems.append("Could not install Python modules: " + (r.stderr or r.stdout))

def module_ok(module):
    if not VENV_PYTHON.exists():
        return False
    r = run([str(VENV_PYTHON), "-c", f"import {module}; print('ok')"], timeout=60)
    return r.returncode == 0

def server_url():
    cfg = read_json(APP_DIR / "license_server_config.json", {})
    url = str(cfg.get("server_url", "")).strip()
    if not url or "127.0.0.1" in url or "localhost" in url:
        return "https://uas-license-server.onrender.com"
    return url.rstrip("/")

def check_server(warnings):
    url = server_url()
    try:
        with urllib.request.urlopen(url + "/health", timeout=20) as r:
            body = r.read().decode("utf-8", errors="replace")
        if "ok" not in body.lower():
            warnings.append("License server health response unexpected: " + body[:120])
    except Exception as e:
        warnings.append(f"License server health check warning: {e}")

def main():
    problems = []
    warnings = []

    for f in REQUIRED_FILES:
        if not (APP_DIR / f).exists():
            problems.append(f"Missing required file: {f}")

    try:
        temp_root = Path(tempfile.mkdtemp(prefix="uas_smoke_"))
        test = temp_root / "write_test.txt"
        test.write_text("ok", encoding="utf-8")
        shutil.rmtree(temp_root, ignore_errors=True)
    except Exception as e:
        problems.append(f"Temp write test failed: {e}")

    ensure_venv(problems, warnings)

    for m in REQUIRED_MODULES:
        if not module_ok(m):
            problems.append(f"Missing Python module in runtime venv: {m}")

    check_server(warnings)

    if not (APP_DIR / "user_profile.json").exists():
        warnings.append("No user_profile.json yet. Onboarding has not been completed yet.")
    if not (APP_DIR / "license.json").exists():
        warnings.append("No license.json yet. Device has not been activated yet.")
    if not (APP_DIR / "device.json").exists():
        warnings.append("No device.json yet. Device ID has not been created yet.")

    report = {
        "created_at": now(),
        "ready": len(problems) == 0,
        "problems": problems,
        "warnings": warnings,
        "environment": {
            "app_dir": str(APP_DIR),
            "server_url": server_url(),
            "system_python": sys.executable,
            "runtime_python": str(VENV_PYTHON),
            "report_json": str(REPORT_JSON),
            "report_txt": str(REPORT_TXT)
        }
    }

    write_report(report)

    print("SYSTEM_CHECK_DONE")
    print(f"READY={report['ready']}")
    print(f"REPORT_JSON={REPORT_JSON}")
    print(f"REPORT_TXT={REPORT_TXT}")
    if problems:
        print("PROBLEMS_FOUND=" + " | ".join(problems))
    if warnings:
        print("WARNINGS_FOUND=" + " | ".join(warnings))

    return 0 if report["ready"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
