from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

import urllib.request
import urllib.error

APP_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = Path.home() / "Library" / "Application Support" / "UASGenerator2026V2"
VENV_DIR = RUNTIME_DIR / "runtime_venv"
REPORT_JSON = RUNTIME_DIR / "support_report.json"
REPORT_TXT = RUNTIME_DIR / "support_report.txt"
PRODUCTION_SERVER_URL = "https://uas-license-server.onrender.com"

REQUIRED_FILES = [
    "system_check.py",
    "activate_license.py",
    "license_manager.py",
    "generate_outputs.py",
    "app_mac.py",
    "bootstrap_runtime.py",
    "csv_extractors.py",
    "postprocess_tt.py",
    "phq9_patch.py",
    "commercial_profile.py",
    "cmvisit.py",
    "uas_automation.py",
    "tt_service_patch.py",
    "config.json",
    "license_server_config.json",
    "Terms_of_Use.txt",
    "README.txt",
    "TT_template.xlsx",
    "CDPAS_template.xlsx",
    "FRA_template.pdf",
    "PHQ9_template.pdf",
    "CM_InPerson_Visit_Template.pdf",
]

REQUIRED_PACKAGES = ["pandas", "openpyxl", "pypdf", "reportlab", "requests", "certifi"]


def read_json(path: Path, default: Any) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def get_server_url() -> str:
    cfg = read_json(APP_DIR / "license_server_config.json", {})
    url = str(cfg.get("server_url") or PRODUCTION_SERVER_URL).strip().rstrip("/")
    if not url:
        url = PRODUCTION_SERVER_URL
    blocked_hosts = ["local" + "host", "127" + ".0.0.1", "0" + ".0.0.0"]
    insecure_scheme = "ht" + "tp://"
    if any(x in url for x in blocked_hosts) or url.startswith(insecure_scheme):
        raise RuntimeError(f"Invalid production license server URL: {url}")
    return url


def venv_python() -> Path:
    return VENV_DIR / "bin" / "python3"


def run_cmd(cmd: list[str], timeout: int = 300) -> Dict[str, Any]:
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return {"ok": p.returncode == 0, "returncode": p.returncode, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:]}
    except Exception as exc:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": str(exc)}


def ensure_runtime_venv(report: Dict[str, Any]) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    if not venv_python().exists():
        created = run_cmd([sys.executable, "-m", "venv", str(VENV_DIR)])
        report["runtime"]["venv_create"] = created
        if not created["ok"]:
            report["summary"]["problems"].append("Could not create runtime_venv outside app bundle.")
            return
    upgrade = run_cmd([str(venv_python()), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], timeout=600)
    install = run_cmd([str(venv_python()), "-m", "pip", "install", *REQUIRED_PACKAGES], timeout=900)
    report["runtime"]["pip_upgrade"] = upgrade
    report["runtime"]["pip_install"] = install
    if not upgrade["ok"]:
        report["summary"]["problems"].append("Could not upgrade pip in runtime_venv.")
    if not install["ok"]:
        report["summary"]["problems"].append("Could not install required Python dependencies in runtime_venv.")


def verify_imports(report: Dict[str, Any]) -> None:
    imports = {}
    for mod in REQUIRED_PACKAGES:
        py_mod = mod
        code = f"import {py_mod}; print('OK')"
        result = run_cmd([str(venv_python()), "-c", code], timeout=120)
        imports[mod] = result
        if not result["ok"]:
            report["summary"]["problems"].append(f"Missing required Python module in runtime_venv: {mod}")
    report["imports"] = imports


def http_post_empty(url: str):
    result = {
        "ok": False,
        "status": None,
        "error": "",
        "body_preview": "",
    }

    try:
        req = urllib.request.Request(
            url,
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=45) as resp:
                status = int(resp.getcode())
                body = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            status = int(exc.code)
            body = exc.read().decode("utf-8", errors="replace")

        result["status"] = status
        result["body_preview"] = body[:500]

        # Important:
        # 422 means the endpoint is reachable and correctly rejected an empty test body.
        # 401/403 also mean the endpoint is reachable.
        # Only network errors and 5xx server errors should fail reachability.
        result["ok"] = 200 <= status < 500

    except Exception as exc:
        result["error"] = str(exc)

    return result

def check_write(path: Path) -> Dict[str, Any]:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("ok", encoding="utf-8")
        path.unlink(missing_ok=True)
        return {"ok": True, "error": ""}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def main() -> int:
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "app_dir": str(APP_DIR),
        "runtime_dir": str(RUNTIME_DIR),
        "runtime_venv": str(VENV_DIR),
        "server": {},
        "system": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "python": sys.executable,
            "python_version": sys.version,
        },
        "required_files": {},
        "runtime": {},
        "imports": {},
        "write_checks": {},
        "summary": {"ready": False, "problems": [], "warnings": []},
    }

    try:
        server_url = get_server_url()
    except Exception as exc:
        server_url = ""
        report["summary"]["problems"].append(str(exc))

    for rel in REQUIRED_FILES:
        p = APP_DIR / rel
        exists = p.exists() and p.is_file()
        report["required_files"][rel] = {"exists": exists, "size": p.stat().st_size if exists else 0}
        if not exists:
            report["summary"]["problems"].append(f"Missing required file: {rel}")

    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    report["write_checks"]["runtime_dir"] = check_write(RUNTIME_DIR / "_runtime_write_probe")
    if not report["write_checks"]["runtime_dir"]["ok"]:
        report["summary"]["problems"].append("Runtime folder is not writable.")

    if str(APP_DIR).endswith(".app") or ".app/Contents/Resources" in str(APP_DIR):
        report["summary"]["warnings"].append("Running from app resources. Mutable files must remain in runtime_dir.")

    ensure_runtime_venv(report)
    if venv_python().exists():
        verify_imports(report)
    else:
        report["summary"]["problems"].append("runtime_venv python was not created.")

    if server_url:
        report["server"]["server_url"] = server_url
        report["server"]["activate_license_endpoint"] = http_post_empty(f"{server_url}/activate-license")
        report["server"]["validate_license_endpoint"] = http_post_empty(f"{server_url}/validate-license")
        if not report["server"]["activate_license_endpoint"]["ok"]:
            report["summary"]["problems"].append("License server activate endpoint is not reachable.")
        if not report["server"]["validate_license_endpoint"]["ok"]:
            report["summary"]["problems"].append("License server validate endpoint is not reachable.")

    config = read_json(APP_DIR / "config.json", {})
    output_folder = str(config.get("output_folder", "")).strip()
    if output_folder:
        out_path = Path(output_folder).expanduser()
        report["write_checks"]["configured_output_folder"] = check_write(out_path / "_output_write_probe")
        if not report["write_checks"]["configured_output_folder"]["ok"]:
            report["summary"]["warnings"].append(f"Configured output folder is not writable: {output_folder}")
    else:
        report["summary"]["warnings"].append("No configured output folder yet. User will choose output folder during normal use.")

    report["summary"]["ready"] = len(report["summary"]["problems"]) == 0

    write_json(REPORT_JSON, report)

    lines = []
    lines.append("UAS GENERATOR SYSTEM CHECK REPORT")
    lines.append(f"Generated at: {report['generated_at']}")
    lines.append(f"App resources: {report['app_dir']}")
    lines.append(f"Runtime folder: {report['runtime_dir']}")
    lines.append(f"Runtime venv: {report['runtime_venv']}")
    lines.append("")
    lines.append("SERVER")
    lines.append(f"server_url: {report['server'].get('server_url', '')}")
    lines.append(f"activate_endpoint_ok: {report['server'].get('activate_license_endpoint', {}).get('ok')}")
    lines.append(f"validate_endpoint_ok: {report['server'].get('validate_license_endpoint', {}).get('ok')}")
    lines.append("")
    lines.append("REQUIRED FILES")
    for k, v in report["required_files"].items():
        lines.append(f"{k}: exists={v['exists']} size={v['size']}")
    lines.append("")
    lines.append("IMPORTS")
    for k, v in report["imports"].items():
        lines.append(f"{k}: ok={v['ok']}")
    lines.append("")
    lines.append("PROBLEMS")
    if report["summary"]["problems"]:
        lines.extend(report["summary"]["problems"])
    else:
        lines.append("none")
    lines.append("")
    lines.append("WARNINGS")
    if report["summary"]["warnings"]:
        lines.extend(report["summary"]["warnings"])
    else:
        lines.append("none")
    lines.append("")
    lines.append(f"READY={report['summary']['ready']}")
    REPORT_TXT.write_text("\n".join(lines), encoding="utf-8")

    print(f"READY={report['summary']['ready']}")
    print(f"REPORT_JSON={REPORT_JSON}")
    print(f"REPORT_TXT={REPORT_TXT}")
    if report["summary"]["problems"]:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
