UAS Generator 2026 V2 - Mac Setup

1. Download and unzip this file.
2. Drag "UAS Generator.app" into Applications.
3. Open Applications.
4. Right-click "UAS Generator.app" and click Open.
5. If macOS blocks it, go to System Settings > Privacy & Security > Open Anyway.
6. Run System Check first.
7. Complete onboarding.
8. Enter your email and license key.
9. Select your UAS CSV file and generate documents.
10. Review all generated documents before submission.

Important:
Internet is required for license activation.
The user is responsible for reviewing all generated documents before submission.
