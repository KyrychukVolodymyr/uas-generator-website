import argparse
from license_manager import activate_with_server

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--key", required=True)
    parser.add_argument("--email", required=True)
    parser.add_argument("--terms-version", default="2026-04-21-v2")
    parser.add_argument("--app-version", default="v1")
    args = parser.parse_args()

    record = activate_with_server(
        email=args.email.strip(),
        license_key=args.key.strip(),
        accepted_terms_version=args.terms_version.strip(),
        app_version=args.app_version.strip()
    )
    print(record)

if __name__ == "__main__":
    main()
