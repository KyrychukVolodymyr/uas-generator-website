import json
import os
import urllib.request
import urllib.error
import uuid
from datetime import datetime, timezone
from pathlib import Path

if getattr(__import__("sys"), "frozen", False):
    APP_DIR = Path(__import__("sys").executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

DEVICE_PATH = APP_DIR / "device.json"
LICENSE_PATH = APP_DIR / "license.json"
USER_PROFILE_PATH = APP_DIR / "user_profile.json"
SERVER_CONFIG_PATH = APP_DIR / "license_server_config.json"

def _now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def _read_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default

def _write_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def get_server_url() -> str:
    cfg = _read_json(SERVER_CONFIG_PATH, {})
    url = str(cfg.get("server_url", "")).strip() or "https://uas-license-server.onrender.com"
    return url.rstrip("/")

def get_or_create_device_id() -> str:
    existing = _read_json(DEVICE_PATH, {})
    device_id = str(existing.get("device_id", "")).strip()
    if device_id:
        return device_id

    device_id = str(uuid.uuid4())
    payload = {
        "device_id": device_id,
        "created_at": _now_iso(),
        "hostname": os.uname().nodename if hasattr(os, "uname") else ""
    }
    _write_json(DEVICE_PATH, payload)
    return device_id

def load_license_record() -> dict:
    return _read_json(LICENSE_PATH, {})

def load_user_profile() -> dict:
    return _read_json(USER_PROFILE_PATH, {})

def _hostname() -> str:
    return os.uname().nodename if hasattr(os, "uname") else ""

def _post_json(url: str, payload: dict) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore").strip()
        msg = body or f"HTTP {e.code}"
        try:
            parsed = json.loads(body)
            if isinstance(parsed, dict) and parsed.get("detail"):
                msg = str(parsed["detail"])
        except Exception:
            pass
        raise RuntimeError(msg)
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach license server: {e.reason}")
    except Exception as e:
        raise RuntimeError(str(e))

def activate_with_server(email: str, license_key: str, accepted_terms_version: str, app_version: str = "v1") -> dict:
    device_id = get_or_create_device_id()
    payload = {
        "email": email.strip().lower(),
        "license_key": license_key.strip(),
        "device_id": device_id,
        "hostname": _hostname(),
        "accepted_terms_version": accepted_terms_version.strip(),
        "app_version": app_version.strip()
    }
    data = _post_json(f"{get_server_url()}/activate-license", payload)

    record = {
        "license_key": license_key.strip(),
        "license": {
            "email": email.strip().lower(),
            "status": data.get("status", ""),
            "tier": data.get("tier", ""),
            "expires_at": data.get("expires_at", ""),
            "max_devices": data.get("max_devices", 1),
            "bound_device_id": device_id,
            "activated_at": _now_iso(),
            "last_validated_at": _now_iso()
        },
        "server_url": get_server_url()
    }
    _write_json(LICENSE_PATH, record)
    return record

def validate_with_server() -> dict:
    profile = load_user_profile()
    record = load_license_record()

    email = str(profile.get("email", "")).strip().lower()
    license_key = str(record.get("license_key", "")).strip()
    device_id = get_or_create_device_id()

    if not email:
        raise RuntimeError("Missing onboarding email.")
    if not license_key:
        raise RuntimeError("No active license. Complete onboarding again.")

    payload = {
        "email": email,
        "license_key": license_key,
        "device_id": device_id,
        "hostname": _hostname(),
        "app_version": "v1"
    }
    data = _post_json(f"{get_server_url()}/validate-license", payload)

    existing = load_license_record()
    existing.setdefault("license", {})
    existing["license"]["email"] = email
    existing["license"]["status"] = data.get("status", "")
    existing["license"]["expires_at"] = data.get("expires_at", "")
    existing["license"]["max_devices"] = data.get("max_devices", 1)
    existing["license"]["bound_device_id"] = device_id
    existing["license"]["last_validated_at"] = _now_iso()
    existing["server_url"] = get_server_url()
    _write_json(LICENSE_PATH, existing)

    return {
        "valid": True,
        "reason": "ok",
        "license": existing.get("license", {}),
        "device_id": device_id
    }

def get_license_status() -> dict:
    try:
        return validate_with_server()
    except Exception as e:
        return {"valid": False, "reason": str(e)}

def require_active_license():
    status = get_license_status()
    if not status.get("valid"):
        raise RuntimeError(
            "License check failed.\n\n"
            + status.get("reason", "Unknown license error.")
            + "\n\nMake sure the license server is running and this device is activated."
        )
    return status
