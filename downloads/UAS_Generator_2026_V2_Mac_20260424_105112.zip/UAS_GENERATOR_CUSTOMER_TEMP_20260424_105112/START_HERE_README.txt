UAS Generator 2026 V2 - Mac Setup

1. Double-click "UAS Generator.app".
2. Run System Check first.
3. Continue only after System Check passes.
4. Complete onboarding.
5. Enter your email and license key.
6. Select your UAS CSV file.
7. Generate documents.
8. Review all documents before submission.

Important:
Internet is required for license activation.
Do not delete files inside this folder.
The user is responsible for reviewing all generated documents.
