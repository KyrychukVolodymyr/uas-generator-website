set -euo pipefail

# ---- Build variant: commercial (default) or personal (--personal / UAS_PERSONAL_BUILD=1) ----
# Mirrors the variant logic in mac_final_build.sh so this dry run is a faithful proxy.
PERSONAL_BUILD=0
for _arg in "$@"; do
  case "$_arg" in
    --personal) PERSONAL_BUILD=1 ;;
  esac
done
if [ "${UAS_PERSONAL_BUILD:-}" = "1" ]; then PERSONAL_BUILD=1; fi

SRC="$HOME/Desktop/UAS_Doc_Generation_Naming_Aug2026"

BUNDLE_NAME="Document Generator"
BUNDLE_ID="com.local.uasgenerator2026v2"
VARIANT="commercial"
if [ "$PERSONAL_BUILD" = "1" ]; then
  export UAS_PERSONAL_BUILD=1
  BUNDLE_NAME="Document Generator (Personal)"
  BUNDLE_ID="com.local.uasgenerator2026v2.personal"
  VARIANT="personal"
fi

STAMP="$(date '+%Y%m%d_%H%M%S')"
ROOT="/private/tmp/UAS_MAC_DRYRUN_${VARIANT}_$STAMP"
PKG="$ROOT/UAS_Generator_Mac"
APP="$PKG/UAS Generator.app"
CONTENTS="$APP/Contents"
MACOS="$CONTENTS/MacOS"
RES="$CONTENTS/Resources"
EXE="$MACOS/UASGeneratorFrontend"
BUILD="$ROOT/swift_build"
REPORT="$SRC/MAC_DRYRUN_REPORT_${VARIANT}_$STAMP.txt"

mkdir -p "$ROOT" "$PKG" "$MACOS" "$RES" "$BUILD"
: > "$REPORT"

log() { echo "$@" | tee -a "$REPORT"; }
section() {
  echo "" | tee -a "$REPORT"
  echo "============================================================" | tee -a "$REPORT"
  echo "$@" | tee -a "$REPORT"
  echo "============================================================" | tee -a "$REPORT"
}

section "GATE 0 — SOURCE CHECK"
log "Source: $SRC"
[ -d "$SRC" ] || { log "FAIL source folder missing."; exit 1; }
cd "$SRC"
for f in UASGeneratorFrontend.swift "UAS Generator.app/Contents/Info.plist" app_mac.py generate_outputs.py license_manager.py activate_license.py system_check.py bootstrap_runtime.py uas_automation.py cmvisit.py tt_service_patch.py postprocess_tt.py csv_extractors.py commercial_profile.py phq9_patch.py config.json license_server_config.json Terms_of_Use.txt LICENSE.txt README.txt TT_template.xlsx CDPAS_template.xlsx FRA_template.pdf PHQ9_template.pdf CM_InPerson_Visit_Template.pdf anthem_logo.jpeg anthem_logo_cdpas.jpeg; do
  if [ -e "$f" ]; then log "PASS exists: $f"; else log "FAIL missing: $f"; exit 1; fi
done
python3 -m py_compile generate_outputs.py app_mac.py license_manager.py activate_license.py system_check.py bootstrap_runtime.py cmvisit.py uas_automation.py tt_service_patch.py postprocess_tt.py csv_extractors.py commercial_profile.py phq9_patch.py
log "PASS Python compile check."

section "GATE 1 — SKIPPED (dry run, no signing/notary precondition check)"

section "GATE 2 — COPY CLEAN PACKAGE ROOT FILES"
find "$SRC" -maxdepth 1 -type f -print0 | while IFS= read -r -d '' f; do
  name="$(basename "$f")"
  case "$name" in
    *.bak|*.backup|*.pyc|*.log|*.csv|*REPORT*.txt|support_report.*|*-TT.xlsx|*-TT.pdf|*-CDPAS.xlsx|*-CDPAS.pdf|*-FRA.pdf|*-PHQ9.pdf|*-6monthCMVisit.pdf|*backup*|*.original*|*BAD_BEFORE*|*BROKEN*|*BEFORE_*) ;;
    *) COPYFILE_DISABLE=1 cp -X -p "$f" "$PKG/" ;;
  esac
done
log "PASS clean package root copied."

section "GATE 3 — BUILD UNIVERSAL SWIFT FRONTEND"
swiftc -target arm64-apple-macos11.0 -parse-as-library "$SRC/UASGeneratorFrontend.swift" -o "$BUILD/UASGeneratorFrontend_arm64" 2>&1 | tee -a "$REPORT"
swiftc -target x86_64-apple-macos11.0 -parse-as-library "$SRC/UASGeneratorFrontend.swift" -o "$BUILD/UASGeneratorFrontend_x86_64" 2>&1 | tee -a "$REPORT"
lipo -create "$BUILD/UASGeneratorFrontend_arm64" "$BUILD/UASGeneratorFrontend_x86_64" -output "$BUILD/UASGeneratorFrontend_universal"
COPYFILE_DISABLE=1 cp -X -p "$SRC/UAS Generator.app/Contents/Info.plist" "$CONTENTS/Info.plist"
if [ "$PERSONAL_BUILD" = "1" ]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleName $BUNDLE_NAME" "$CONTENTS/Info.plist"
  /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName $BUNDLE_NAME" "$CONTENTS/Info.plist" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string $BUNDLE_NAME" "$CONTENTS/Info.plist"
  /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$CONTENTS/Info.plist"
  /usr/libexec/PlistBuddy -c "Add :LSEnvironment dict" "$CONTENTS/Info.plist" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :LSEnvironment:UAS_PERSONAL_BUILD string 1" "$CONTENTS/Info.plist" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Set :LSEnvironment:UAS_PERSONAL_BUILD 1" "$CONTENTS/Info.plist"
  log "PERSONAL Info.plist overrides applied: name='$BUNDLE_NAME' id='$BUNDLE_ID' LSEnvironment.UAS_PERSONAL_BUILD=1"
fi
COPYFILE_DISABLE=1 cp -X -p "$BUILD/UASGeneratorFrontend_universal" "$EXE"
chmod 755 "$EXE"
file "$EXE" 2>&1 | tee -a "$REPORT"
lipo -info "$EXE" 2>&1 | tee -a "$REPORT"
ARCH_INFO="$(lipo -info "$EXE" 2>/dev/null || true)"
if echo "$ARCH_INFO" | grep -q "x86_64" && echo "$ARCH_INFO" | grep -q "arm64"; then
  log "PASS app executable is universal2."
else
  log "FAIL app executable is not universal2."; exit 1
fi

section "GATE 4 — COPY APP RESOURCES"
FILES=(
  "app_mac.py" "generate_outputs.py" "uas_automation.py" "tt_service_patch.py"
  "postprocess_tt.py" "csv_extractors.py" "commercial_profile.py" "license_manager.py"
  "system_check.py" "cmvisit.py" "activate_license.py" "bootstrap_runtime.py"
  "phq9_patch.py" "config.json" "license_server_config.json" "Terms_of_Use.txt"
  "LICENSE.txt" "README.txt" "CDPAS_template.xlsx" "TT_template.xlsx"
  "FRA_template.pdf" "PHQ9_template.pdf" "CM_InPerson_Visit_Template.pdf"
  "anthem_logo.jpeg" "anthem_logo_cdpas.jpeg"
)
for f in "${FILES[@]}"; do
  if [ -f "$SRC/$f" ]; then
    COPYFILE_DISABLE=1 cp -X -p "$SRC/$f" "$RES/$f"
    log "PASS copied resource: $f"
  else
    log "FAIL missing required resource: $f"; exit 1
  fi
done

section "DRY RUN COMPLETE ($VARIANT) — stopped before signing (Gates 7-16 not run)"
log "Variant: $VARIANT  name='$BUNDLE_NAME'  id='$BUNDLE_ID'"
log "Package root: $PKG"
log "Universal binary: $EXE"
log "Report: $REPORT"
