import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
REPORT_JSON = APP_DIR / "support_report.json"
REPORT_TXT = APP_DIR / "support_report.txt"

MIN_MACOS_MAJOR = 11
MIN_FREE_DISK_GB = 1

REQUIRED_FILES = [
    "app_mac.py",
    "generate_outputs.py",
    "license_manager.py",
    "commercial_profile.py",
    "UASGeneratorFrontend.swift",
    "UAS Generator.app/Contents/MacOS/UASGeneratorFrontend",
    "license_server_config.json",
    "FRA_template.pdf",
    "PHQ9_template.pdf",
    "CDPAS_template.xlsx",
    "TT_template.xlsx",
]

OPTIONAL_FILES = [
    "user_profile.json",
    "license.json",
    "device.json",
    "config.json",
]

REQUIRED_IMPORTS = [
    "json",
    "urllib.request",
    "openpyxl",
    "pypdf",
    "pandas",
]

def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default if default is not None else {}

def try_import(name: str):
    try:
        __import__(name)
        return True, ""
    except Exception as e:
        return False, repr(e)

def run_cmd(cmd, timeout=30):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {
            "returncode": out.returncode,
            "stdout": out.stdout.strip(),
            "stderr": out.stderr.strip(),
        }
    except Exception as e:
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": repr(e),
        }

def http_get(url, timeout=10):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="ignore")
            return {"ok": True, "status": resp.status, "body": body[:1500]}
    except Exception as e:
        return {"ok": False, "status": None, "body": repr(e)}

def check_write_access(path: Path):
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / f".write_test_{os.getpid()}.tmp"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True, ""
    except Exception as e:
        return False, repr(e)

def get_server_url():
    cfg = read_json(APP_DIR / "license_server_config.json", {})
    url = str(cfg.get("server_url", "http://127.0.0.1:8000")).strip()
    return (url or "http://127.0.0.1:8000").rstrip("/")

def parse_macos_version():
    version = platform.mac_ver()[0].strip()
    major = 0
    minor = 0
    patch = 0
    try:
        parts = version.split(".")
        if len(parts) > 0:
            major = int(parts[0])
        if len(parts) > 1:
            minor = int(parts[1])
        if len(parts) > 2:
            patch = int(parts[2])
    except Exception:
        pass
    return version, major, minor, patch

def get_disk_info(path: Path):
    usage = shutil.disk_usage(path)
    return {
        "total_gb": round(usage.total / (1024**3), 2),
        "used_gb": round(usage.used / (1024**3), 2),
        "free_gb": round(usage.free / (1024**3), 2),
    }

def find_sample_csv():
    preferred = sorted(APP_DIR.glob("synthetic*.csv"))
    if preferred:
        return preferred[0]
    all_csv = sorted(APP_DIR.glob("*.csv"))
    if all_csv:
        return all_csv[0]
    return None

def generation_smoke_test():
    sample_csv = find_sample_csv()
    if not sample_csv:
        return {
            "ok": False,
            "warning_only": True,
            "sample_csv": "",
            "message": "No sample CSV found in project folder; generation smoke test skipped."
        }

    temp_root = Path(tempfile.mkdtemp(prefix="uas_smoke_", dir=str(APP_DIR)))
    smoke_output = temp_root / "output"
    smoke_output.mkdir(parents=True, exist_ok=True)

    py = sys.executable
    code = r'''
from pathlib import Path
import traceback
import json
import re
import app_mac

app_mac.re = re
app_mac.require_active_license = lambda: {"valid": True, "reason": "smoke-test-bypass"}

csv_path = Path(r"__CSV__")
output_path = Path(r"__OUT__")

try:
    result = app_mac.perform_generation(
        csv_path_str=str(csv_path),
        patient_string="SYSTEMCHECK_999999",
        output_override=str(output_path),
        days_per_week="5",
        hours_per_day="6",
        bedrooms_count="2",
        accessible_home="no",
        equipment={
            "cane": False,
            "walker": False,
            "wheelchair": False,
            "hospital_bed": False,
            "catheter": False,
            "grab_bar": False,
            "bedside_commode": False,
            "oxygen": False,
            "service": False,
            "hoyer_lift": False,
            "raised_toilet_seat": False,
            "shower_chair": False,
            "cdpas_aspiration_precautions": False,
            "cdpas_tube_feeding": False,
            "cdpas_oxygen_care": False,
            "cdpas_catheter_type": "",
        },
        dwelling_type="apartment_elevator",
        service_flag=False,
    )
    created = []
    for p in output_path.rglob("*"):
        if p.is_file():
            created.append(str(p))
    print(json.dumps({
        "ok": True,
        "result": str(result),
        "created_count": len(created),
        "created_files": created[:25]
    }, ensure_ascii=False))
except Exception as e:
    print(json.dumps({
        "ok": False,
        "error": str(e),
        "traceback": traceback.format_exc()
    }, ensure_ascii=False))
'''
    code = code.replace("__CSV__", str(sample_csv)).replace("__OUT__", str(smoke_output))

    proc = subprocess.run(
        [py, "-c", code],
        cwd=str(APP_DIR),
        capture_output=True,
        text=True,
        timeout=180
    )

    stdout = proc.stdout.strip()
    stderr = proc.stderr.strip()

    parsed = None
    try:
        parsed = json.loads(stdout) if stdout else None
    except Exception:
        parsed = None

    files_created = []
    if smoke_output.exists():
        files_created = [str(p) for p in smoke_output.rglob("*") if p.is_file()]

    result = {
        "ok": bool(parsed and parsed.get("ok")),
        "warning_only": False,
        "sample_csv": str(sample_csv),
        "returncode": proc.returncode,
        "stdout": stdout[:4000],
        "stderr": stderr[:2000],
        "files_created_count": len(files_created),
        "files_created_preview": files_created[:25],
        "temp_output_dir": str(smoke_output),
    }

    if parsed and parsed.get("ok"):
        result["message"] = "Generation smoke test passed."
    elif parsed and not parsed.get("ok"):
        result["message"] = f"Generation smoke test failed: {parsed.get('error','unknown error')}"
        result["traceback"] = parsed.get("traceback", "")
    else:
        result["message"] = "Generation smoke test failed: could not parse subprocess output."

    return result

def main():
    server_url = get_server_url()
    docs_dir = Path.home() / "Documents"
    output_cfg = read_json(APP_DIR / "config.json", {})
    configured_output = Path(str(output_cfg.get("output_folder", "")).strip()).expanduser() if output_cfg.get("output_folder") else None

    report = {
        "generated_at": now_iso(),
        "app_dir": str(APP_DIR),
        "system": {},
        "compatibility": {},
        "paths": {},
        "required_files": {},
        "optional_files": {},
        "imports": {},
        "commands": {},
        "server": {},
        "writable_checks": {},
        "disk": {},
        "generation_smoke_test": {},
        "summary": {
            "ready": False,
            "problems": [],
            "warnings": [],
        }
    }

    system_name = platform.system().strip()
    mac_ver, mac_major, mac_minor, mac_patch = parse_macos_version()
    machine = platform.machine().strip().lower()
    hostname = socket.gethostname()

    report["system"] = {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "system_name": system_name,
        "machine": machine,
        "processor": platform.processor(),
        "hostname": hostname,
        "mac_ver": mac_ver,
    }

    report["compatibility"] = {
        "supported_os": system_name == "Darwin",
        "supported_macos": mac_major >= MIN_MACOS_MAJOR if system_name == "Darwin" else False,
        "supported_architecture": machine in {"arm64", "x86_64"} if system_name == "Darwin" else False,
        "minimum_macos_major": MIN_MACOS_MAJOR,
        "detected_macos_major": mac_major,
        "detected_macos_minor": mac_minor,
        "detected_macos_patch": mac_patch,
    }

    if system_name != "Darwin":
        report["summary"]["problems"].append(f"Unsupported operating system: {system_name}. This release is Mac-only.")
    if system_name == "Darwin" and mac_major < MIN_MACOS_MAJOR:
        report["summary"]["problems"].append(f"Unsupported macOS version: {mac_ver}. Minimum supported major version is {MIN_MACOS_MAJOR}.")
    if system_name == "Darwin" and machine not in {"arm64", "x86_64"}:
        report["summary"]["problems"].append(f"Unsupported architecture: {machine}. Expected arm64 or x86_64.")

    for rel in REQUIRED_FILES:
        path = APP_DIR / rel
        report["required_files"][rel] = {
            "exists": path.exists(),
            "size": path.stat().st_size if path.exists() and path.is_file() else None
        }
        if not path.exists():
            report["summary"]["problems"].append(f"Missing required file: {rel}")

    for rel in OPTIONAL_FILES:
        path = APP_DIR / rel
        report["optional_files"][rel] = {
            "exists": path.exists(),
            "size": path.stat().st_size if path.exists() and path.is_file() else None
        }

    for mod in REQUIRED_IMPORTS:
        ok, err = try_import(mod)
        report["imports"][mod] = {"ok": ok, "error": err}
        if not ok:
            report["summary"]["problems"].append(f"Missing required Python module: {mod}")

    report["commands"]["uname_m"] = run_cmd(["uname", "-m"])
    report["commands"]["sw_vers"] = run_cmd(["sw_vers"])
    report["commands"]["python_version"] = run_cmd([sys.executable, "--version"])

    report["disk"]["app_dir"] = get_disk_info(APP_DIR)
    report["disk"]["home_documents"] = get_disk_info(docs_dir if docs_dir.exists() else Path.home())

    if report["disk"]["app_dir"]["free_gb"] < MIN_FREE_DISK_GB:
        report["summary"]["problems"].append(f"Low free disk space near app directory: {report['disk']['app_dir']['free_gb']} GB.")
    if report["disk"]["home_documents"]["free_gb"] < MIN_FREE_DISK_GB:
        report["summary"]["warnings"].append(f"Low free disk space near Documents: {report['disk']['home_documents']['free_gb']} GB.")

    ok, err = check_write_access(APP_DIR / "_system_check_probe")
    report["writable_checks"]["app_dir_probe"] = {"ok": ok, "error": err}
    shutil.rmtree(APP_DIR / "_system_check_probe", ignore_errors=True)
    if not ok:
        report["summary"]["problems"].append("Cannot write inside project folder.")

    ok, err = check_write_access(docs_dir)
    report["writable_checks"]["documents_folder"] = {"ok": ok, "error": err}
    if not ok:
        report["summary"]["problems"].append("Cannot write to Documents folder.")

    if configured_output:
        ok, err = check_write_access(configured_output)
        report["writable_checks"]["configured_output_folder"] = {
            "path": str(configured_output),
            "ok": ok,
            "error": err
        }
        if not ok:
            report["summary"]["problems"].append(f"Configured output folder is not writable: {configured_output}")
    else:
        report["summary"]["warnings"].append("No configured output folder found in config.json.")

    report["server"]["server_url"] = server_url
    report["server"]["health"] = http_get(f"{server_url}/health")
    report["server"]["docs"] = http_get(f"{server_url}/docs")

    if not report["server"]["health"]["ok"]:
        report["summary"]["problems"].append(f"License server not reachable: {server_url}")
    if "127.0.0.1" in server_url or "localhost" in server_url:
        report["summary"]["warnings"].append("Server URL is local development only. Production clients will need a hosted server URL.")

    profile = read_json(APP_DIR / "user_profile.json", {})
    license_json = read_json(APP_DIR / "license.json", {})
    device = read_json(APP_DIR / "device.json", {})

    report["paths"] = {
        "user_profile_email": profile.get("email", ""),
        "device_id": device.get("device_id", ""),
        "license_status_cached": license_json.get("license", {}).get("status", ""),
        "license_server_url_cached": license_json.get("server_url", ""),
        "configured_output_folder": str(configured_output) if configured_output else "",
    }

    if not profile:
        report["summary"]["warnings"].append("No user_profile.json yet. Onboarding may not have been completed.")
    if not license_json:
        report["summary"]["warnings"].append("No license.json yet. Device may not be activated.")
    if not device:
        report["summary"]["warnings"].append("No device.json yet. Device ID has not been created yet.")

    smoke = generation_smoke_test()
    report["generation_smoke_test"] = smoke
    if not smoke.get("ok", False):
        if smoke.get("warning_only", False):
            report["summary"]["warnings"].append(smoke.get("message", "Generation smoke test skipped."))
        else:
            report["summary"]["problems"].append(smoke.get("message", "Generation smoke test failed."))

    report["summary"]["ready"] = len(report["summary"]["problems"]) == 0

    REPORT_JSON.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = []
    lines.append("ENHANCED SYSTEM CHECK REPORT (MAC-ONLY)")
    lines.append(f"Generated at: {report['generated_at']}")
    lines.append(f"Project: {report['app_dir']}")
    lines.append("")
    lines.append("SYSTEM")
    for k, v in report["system"].items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("COMPATIBILITY")
    for k, v in report["compatibility"].items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("SERVER")
    lines.append(f"server_url: {report['server']['server_url']}")
    lines.append(f"health_ok: {report['server']['health']['ok']}")
    lines.append(f"docs_ok: {report['server']['docs']['ok']}")
    lines.append("")
    lines.append("DISK")
    for k, v in report["disk"].items():
        lines.append(f"{k}: total_gb={v['total_gb']} used_gb={v['used_gb']} free_gb={v['free_gb']}")
    lines.append("")
    lines.append("REQUIRED FILES")
    for k, v in report["required_files"].items():
        lines.append(f"{k}: exists={v['exists']} size={v['size']}")
    lines.append("")
    lines.append("OPTIONAL FILES")
    for k, v in report["optional_files"].items():
        lines.append(f"{k}: exists={v['exists']} size={v['size']}")
    lines.append("")
    lines.append("IMPORTS")
    for k, v in report["imports"].items():
        lines.append(f"{k}: ok={v['ok']} error={v['error']}")
    lines.append("")
    lines.append("WRITABLE CHECKS")
    for k, v in report["writable_checks"].items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("GENERATION SMOKE TEST")
    for k, v in report["generation_smoke_test"].items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("PROBLEMS")
    if report["summary"]["problems"]:
        lines.extend(report["summary"]["problems"])
    else:
        lines.append("none")
    lines.append("")
    lines.append("WARNINGS")
    if report["summary"]["warnings"]:
        lines.extend(report["summary"]["warnings"])
    else:
        lines.append("none")
    lines.append("")
    lines.append(f"READY={report['summary']['ready']}")

    REPORT_TXT.write_text("\n".join(lines), encoding="utf-8")

    print("SYSTEM_CHECK_DONE")
    print(f"READY={report['summary']['ready']}")
    print(f"REPORT_JSON={REPORT_JSON}")
    print(f"REPORT_TXT={REPORT_TXT}")
    if report["summary"]["problems"]:
        print("PROBLEMS_FOUND=" + " | ".join(report["summary"]["problems"]))
    if report["summary"]["warnings"]:
        print("WARNINGS_FOUND=" + " | ".join(report["summary"]["warnings"]))

if __name__ == "__main__":
    main()
