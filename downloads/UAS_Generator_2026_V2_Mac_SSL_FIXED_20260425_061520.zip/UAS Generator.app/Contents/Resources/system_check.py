from pathlib import Path
import json
import os
import sys
import tempfile
import shutil
import subprocess
import urllib.request
from datetime import datetime, timezone

APP_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = Path.home() / "Library" / "Application Support" / "UASGenerator2026V2"
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)

REPORT_JSON = RUNTIME_DIR / "support_report.json"
REPORT_TXT = RUNTIME_DIR / "support_report.txt"
VENV_DIR = RUNTIME_DIR / "runtime_venv"
VENV_PYTHON = VENV_DIR / "bin" / "python3"

REQUIRED_FILES = [
    "app_mac.py",
    "generate_outputs.py",
    "license_manager.py",
    "activate_license.py",
    "commercial_profile.py",
    "csv_extractors.py",
    "uas_automation.py",
    "TT_template.xlsx",
    "CDPAS_template.xlsx",
    "FRA_template.pdf",
    "PHQ9_template.pdf",
    "CM_InPerson_Visit_Template.pdf",
    "Terms_of_Use.txt",
    "license_server_config.json"
]

REQUIRED_MODULES = ["pandas", "openpyxl", "pypdf", "requests"]

def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def read_json(path, default):
    try:
        return json.loads(Path(path).read_text())
    except Exception:
        return default

def write_reports(report):
    REPORT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = []
    lines.append("UAS Generator Support Report")
    lines.append(f"Created: {report.get('created_at')}")
    lines.append(f"Ready: {report.get('ready')}")
    lines.append("")
    lines.append("Problems:")
    for item in report.get("problems", []):
        lines.append(f"- {item}")
    lines.append("")
    lines.append("Warnings:")
    for item in report.get("warnings", []):
        lines.append(f"- {item}")
    lines.append("")
    lines.append("Environment:")
    for k, v in report.get("environment", {}).items():
        lines.append(f"- {k}: {v}")
    REPORT_TXT.write_text("\n".join(lines), encoding="utf-8")

def run(cmd, timeout=180):
    return subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)

def ensure_runtime_venv(problems, warnings):
    try:
        if not VENV_PYTHON.exists():
            result = run([sys.executable, "-m", "venv", str(VENV_DIR)], timeout=240)
            if result.returncode != 0:
                problems.append("Could not create bundled runtime Python environment: " + (result.stderr or result.stdout))
                return

        result = run([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], timeout=240)
        if result.returncode != 0:
            warnings.append("Could not upgrade pip: " + (result.stderr or result.stdout))

        result = run([str(VENV_PYTHON), "-m", "pip", "install", "pandas", "openpyxl", "pypdf", "requests"], timeout=600)
        if result.returncode != 0:
            problems.append("Could not install required Python modules: " + (result.stderr or result.stdout))
    except Exception as e:
        problems.append(f"Runtime Python setup failed: {e}")

def module_available_in_venv(module):
    if not VENV_PYTHON.exists():
        return False
    result = run([str(VENV_PYTHON), "-c", f"import {module}; print('ok')"], timeout=60)
    return result.returncode == 0

def can_write_runtime():
    tmp = Path(tempfile.mkdtemp(prefix="uas_check_", dir=str(RUNTIME_DIR)))
    test = tmp / "write_test.txt"
    test.write_text("ok", encoding="utf-8")
    ok = test.read_text(encoding="utf-8") == "ok"
    shutil.rmtree(tmp, ignore_errors=True)
    return ok

def check_license_server():
    cfg = read_json(APP_DIR / "license_server_config.json", {})
    url = cfg.get("server_url") or cfg.get("BASE_URL") or cfg.get("base_url") or "https://uas-license-server.onrender.com"
    if "127.0.0.1" in url or "localhost" in url:
        return False, f"License server URL is local development URL: {url}"
    try:
        health = url.rstrip("/") + "/health"
        with urllib.request.urlopen(health, timeout=10) as r:
            body = r.read().decode("utf-8", errors="ignore")
        if "ok" in body.lower():
            return True, url
        return False, f"License server health response unexpected: {body[:120]}"
    except Exception as e:
        return False, f"License server not reachable now: {url} ({e})"

def main():
    problems = []
    warnings = []

    for f in REQUIRED_FILES:
        if not (APP_DIR / f).exists():
            problems.append(f"Missing required file: {f}")

    try:
        if not can_write_runtime():
            problems.append("Cannot write to Application Support runtime folder")
    except Exception as e:
        problems.append(f"Runtime folder write test failed: {e}")

    ensure_runtime_venv(problems, warnings)

    for module in REQUIRED_MODULES:
        if not module_available_in_venv(module):
            problems.append(f"Missing Python module in runtime environment: {module}")

    ok_server, server_message = check_license_server()
    if not ok_server:
        warnings.append(server_message)

    config = read_json(RUNTIME_DIR / "config.json", read_json(APP_DIR / "config.json", {}))
    if not config.get("output_folder"):
        warnings.append("No configured output folder found yet. User will choose it during setup.")

    if not (RUNTIME_DIR / "user_profile.json").exists():
        warnings.append("No user_profile.json yet. Onboarding has not been completed yet.")

    if not (RUNTIME_DIR / "license.json").exists():
        warnings.append("No license.json yet. Device has not been activated yet.")

    if not (RUNTIME_DIR / "device.json").exists():
        warnings.append("No device.json yet. Device ID has not been created yet.")

    report = {
        "created_at": now_iso(),
        "ready": len(problems) == 0,
        "problems": problems,
        "warnings": warnings,
        "environment": {
            "system_python": sys.executable,
            "runtime_python": str(VENV_PYTHON),
            "app_dir": str(APP_DIR),
            "runtime_dir": str(RUNTIME_DIR),
            "report_json": str(REPORT_JSON),
            "report_txt": str(REPORT_TXT)
        }
    }

    write_reports(report)

    print("SYSTEM_CHECK_DONE")
    print(f"READY={report['ready']}")
    print(f"REPORT_JSON={REPORT_JSON}")
    print(f"REPORT_TXT={REPORT_TXT}")
    if problems:
        print("PROBLEMS_FOUND=" + " | ".join(problems))
    if warnings:
        print("WARNINGS_FOUND=" + " | ".join(warnings))

    return 0 if report["ready"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
