
def strip_excel_comments_vml_parts(xlsx_path):
    """MAC_V20_PATCH6_STRIP_TT_VML: remove comments/VML parts that trigger Excel repair warnings."""
    import zipfile
    import tempfile
    import shutil
    import re
    from pathlib import Path

    xlsx_path = Path(xlsx_path)
    if not xlsx_path.exists():
        return

    tmp = Path(tempfile.mktemp(suffix=".xlsx"))

    remove_name_patterns = (
        "/comments/",
        "comments/comment",
        "vmldrawing",
        "vmlDrawing",
    )

    try:
        with zipfile.ZipFile(xlsx_path, "r") as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                name = item.filename
                lower = name.lower()

                if any(p.lower() in lower for p in remove_name_patterns):
                    continue

                data = zin.read(name)

                if name.endswith(".rels"):
                    try:
                        txt = data.decode("utf-8")
                        txt = re.sub(r'<Relationship[^>]+Target="[^"]*(?:comments|vmlDrawing|vmldrawing)[^"]*"[^>]*/>', '', txt)
                        data = txt.encode("utf-8")
                    except Exception:
                        pass

                elif name.endswith(".xml"):
                    try:
                        txt = data.decode("utf-8")
                        txt = re.sub(r'<legacyDrawing[^>]*/>', '', txt)
                        txt = re.sub(r'<legacyDrawingHF[^>]*/>', '', txt)
                        txt = re.sub(r'<Override[^>]+PartName="[^"]*(?:comments|vmlDrawing|vmldrawing)[^"]*"[^>]*/>', '', txt)
                        data = txt.encode("utf-8")
                    except Exception:
                        pass

                zout.writestr(item, data)

        shutil.move(str(tmp), str(xlsx_path))
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except Exception:
                pass


def reinject_x14_validation(xlsx_path, template_path=None):
    """MAC_V27_REINJECT_B9_DROPDOWN.

    Restore the x14 extended data-validation (the B9 assessment-type dropdown:
    Initial / RA / Ad Hoc) that openpyxl silently strips on every save. Copies the
    primary sheet's <extLst> x14 block verbatim from the bundled TT template into
    the saved output at the zip/XML level. Must run AFTER the final openpyxl save.
    No-op if the block is already present in the output or absent from the template.
    """
    import zipfile
    import re
    import shutil
    import tempfile
    from pathlib import Path

    xlsx_path = Path(xlsx_path)
    if template_path is None:
        template_path = Path(__file__).resolve().parent / "TT_template.xlsx"
    template_path = Path(template_path)
    if not (xlsx_path.exists() and template_path.exists()):
        return False

    def _primary_part(p):
        with zipfile.ZipFile(p) as z:
            wbxml = z.read("xl/workbook.xml").decode("utf-8", "ignore")
            rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8", "ignore")
        rid = re.search(r'<sheet [^>]*r:id="([^"]+)"', wbxml).group(1)
        for m in re.finditer(r'<Relationship\b[^>]*>', rels):
            tag = m.group(0)
            i = re.search(r'Id="([^"]+)"', tag)
            t = re.search(r'Target="([^"]+)"', tag)
            if i and t and i.group(1) == rid:
                tt = t.group(1).lstrip("/")
                return tt if tt.startswith("xl/") else "xl/" + tt
        return None

    try:
        tmpl_part = _primary_part(template_path)
        with zipfile.ZipFile(template_path) as z:
            tmpl_xml = z.read(tmpl_part).decode("utf-8", "ignore")
        m = re.search(r"<extLst>.*?</extLst>", tmpl_xml, re.DOTALL)
        if not m:
            return False
        # xr:uid carries the xmlns:xr namespace that openpyxl's worksheet root may
        # drop; it is optional revision metadata, so strip it to keep the block
        # self-contained (ext declares xmlns:x14, inner block declares xmlns:xm).
        ext_block = re.sub(r'\s+xr:uid="[^"]*"', "", m.group(0))

        out_part = _primary_part(xlsx_path)
        with zipfile.ZipFile(xlsx_path) as z:
            items = z.infolist()
            blobs = {it.filename: z.read(it.filename) for it in items}
        out_xml = blobs[out_part].decode("utf-8", "ignore")
        if "x14:dataValidation" in out_xml or "</worksheet>" not in out_xml:
            return False
        blobs[out_part] = out_xml.replace(
            "</worksheet>", ext_block + "</worksheet>"
        ).encode("utf-8")

        tmp = Path(tempfile.mktemp(suffix=".xlsx"))
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for it in items:
                zout.writestr(it, blobs[it.filename])
        shutil.move(str(tmp), str(xlsx_path))
        return True
    except Exception:
        return False


from openpyxl import load_workbook

def _tt_num(value):
    try:
        if value in (None, ""):
            return 0
        return float(value)
    except Exception:
        return 0

def _tt_recalc_sheet(ws):
    """
    Keep TT formulas alive.

    The program still fills CSV-derived input cells in B:H and I:J.
    This function must NOT replace formula cells with hardcoded numbers.
    K12:K26 and K27 stay as Excel formulas so manual edits recalculate.
    """
    for row in range(12, 27):
        ws[f"K{row}"] = f"=SUM(B{row}:H{row})*I{row}*J{row}"

    ws["K27"] = "=ROUND(SUM(K12:K26)/60,0)"  # MAC_V20_PATCH1_TT_WHOLE_HOURS
    ws["K27"].number_format = "0"  # MAC_V20_PATCH3_TT_WHOLE_NUMBER_DISPLAY
    for _r in range(12, 28):  # MAC_V20_PATCH4_FORCE_WORKBOOK_RECALC
        ws[f"K{_r}"].number_format = "0"
    try:
        wb = ws.parent
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
    except Exception:
        pass

    try:
        wb = ws.parent
        wb.calculation.calcMode = "auto"
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except Exception:
        pass

def _rows_blob(rows):
    parts = []
    for row in rows:
        if isinstance(row, (list, tuple)):
            joined = " | ".join(str(c).strip() for c in row if str(c).strip())
        else:
            joined = str(row).strip()
        if joined:
            parts.append(joined.lower())
    return "\n".join(parts)

def _row_has_minutes(ws, row_num):
    for col in ["B", "C", "D", "E", "F", "G", "H"]:
        v = ws[f"{col}{row_num}"].value
        try:
            if v not in (None, "") and float(v) > 0:
                return True
        except Exception:
            pass
    return False

def apply_tt_schedule_override_v2(xlsx_path, days_per_week, hours_per_day, rows, service_flag=False):
    wb = load_workbook(xlsx_path)
    ws = wb.active

    # Row 32 (K32/B32) population is branch-specific: blanked for SCIC, written
    # for Routine. See the is_scic / else branches below.

    footer_days = days_per_week  # MAC_V20_PATCH1_A36_USES_OVERRIDE_NOT_ROW32
    footer_hours = hours_per_day  # MAC_V20_PATCH1_A36_USES_OVERRIDE_NOT_ROW32

    if footer_days not in (None, "") and footer_hours not in (None, ""):
        footer = f"PCA {footer_days} D x {footer_hours} H"
    elif footer_days not in (None, ""):
        footer = f"PCA {footer_days} D"
    else:
        footer = "PCA"

    if service_flag:
        ws["A36"] = footer + "\nWould like to discuss service hrs with CM."
    else:
        ws["A36"] = footer

    blob = _rows_blob(rows)
    is_scic = "significant change in status reassessment" in blob

    if is_scic:
        # SCIC: full-week task pattern is forced; row 32 stays blank (policy).
        ws["B9"] = "Ad Hoc"  # MAC_V27_TT_B9_ASSESSMENT_TYPE (SCIC -> Ad Hoc, new Anthem 2026 dropdown)
        ws["B32"] = None  # MAC_V20_PATCH1_KEEP_ROW32_BLANK (SCIC only)
        ws["K32"] = None  # MAC_V20_PATCH1_KEEP_ROW32_BLANK (SCIC only)
        scic_rows = {
            12: 7, 13: 7, 14: 3, 15: 7, 16: 2,
            17: 7, 18: 7, 19: 7, 20: 7, 21: 7,
            22: 7, 23: 7, 24: 7
        }
        for r, v in scic_rows.items():
            ws[f"J{r}"] = v
    else:
        # FIX: Routine reassessment — row 32 carries the entered PCA schedule, and
        # PCA-frequency task rows follow the entered days-per-week. Rows 14 and 16
        # are fixed per-task frequencies (the same exception rows the SCIC map
        # treats specially) and are preserved as the CSV ingest wrote them.
        # Rows 25/26 are handled by the laundry logic below.
        ws["B9"] = "RA"  # MAC_V27_TT_B9_ASSESSMENT_TYPE (Routine -> RA, new Anthem 2026 dropdown)
        if hours_per_day is not None:
            ws["B32"] = hours_per_day
        if days_per_week is not None:
            ws["K32"] = days_per_week
        if days_per_week is not None:
            rows_to_override = [12, 13, 15, 17, 18, 19, 20, 21, 22, 23, 24]
            for r in rows_to_override:
                ws[f"J{r}"] = days_per_week

    laundry_continent_active = _row_has_minutes(ws, 25)
    laundry_incontinent_active = _row_has_minutes(ws, 26)

    if laundry_incontinent_active:
        ws["J25"] = None
        ws["J26"] = 3
    elif laundry_continent_active:
        ws["J25"] = 2
        ws["J26"] = None
    else:
        ws["J25"] = None
        ws["J26"] = None

    _tt_recalc_sheet(ws)
    if "Sheet1" in wb.sheetnames:  # MAC_V27_HIDE_TT_DROPDOWN_LIST_SOURCE
        wb["Sheet1"].sheet_state = "hidden"
    for _ws in wb.worksheets:  # MAC_V20_PATCH3_REMOVE_TT_COMMENTS_FOR_EXCEL_COMPAT
        for _row in _ws.iter_rows():
            for _cell in _row:
                if _cell.comment is not None:
                    _cell.comment = None
    wb.save(xlsx_path)
    strip_excel_comments_vml_parts(xlsx_path)  # MAC_V20_PATCH6_STRIP_TT_VML
    reinject_x14_validation(xlsx_path)  # MAC_V27_REINJECT_B9_DROPDOWN (openpyxl strips x14 on save)
