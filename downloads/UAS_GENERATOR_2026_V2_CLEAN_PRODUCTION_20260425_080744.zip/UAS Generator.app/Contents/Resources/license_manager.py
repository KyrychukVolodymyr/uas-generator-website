from pathlib import Path
from datetime import datetime, timezone
import json
import os
import ssl
import time
import urllib.request
import uuid

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "license_server_config.json"
LICENSE_PATH = APP_DIR / "license.json"
DEVICE_PATH = APP_DIR / "device.json"

def _read_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default

def _write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")

def get_server_url():
    cfg = _read_json(CONFIG_PATH, {})
    url = str(cfg.get("server_url", "")).strip()
    if not url or "127.0.0.1" in url or "localhost" in url:
        url = "https://uas-license-server.onrender.com"
    return url.rstrip("/")

def _hostname():
    try:
        return os.uname().nodename
    except Exception:
        return ""

def get_or_create_device_id():
    existing = _read_json(DEVICE_PATH, {})
    device_id = str(existing.get("device_id", "")).strip()
    if device_id:
        return device_id

    device_id = str(uuid.uuid4())
    _write_json(DEVICE_PATH, {
        "device_id": device_id,
        "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "hostname": _hostname()
    })
    return device_id

def _urlopen(req, timeout=75):
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        ctx = ssl._create_unverified_context()

    last = None
    for attempt in range(3):
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=ctx)
        except Exception as e:
            last = e
            time.sleep(2 + attempt * 3)
    raise last

def _post_json(url, payload):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    with _urlopen(req, timeout=75) as resp:
        body = resp.read().decode("utf-8", errors="replace")
        try:
            return json.loads(body)
        except Exception:
            return {"raw": body}

def activate_with_server(email, license_key, accepted_terms_version="2026-04-21-v2", app_version="v1"):
    device_id = get_or_create_device_id()
    payload = {
        "email": email.strip().lower(),
        "license_key": license_key.strip(),
        "device_id": device_id,
        "hostname": _hostname(),
        "accepted_terms_version": accepted_terms_version,
        "app_version": app_version
    }

    data = _post_json(f"{get_server_url()}/activate-license", payload)

    record = {
        "license_key": license_key.strip(),
        "license": {
            "email": data.get("email", email.strip().lower()),
            "status": data.get("status", "active"),
            "tier": data.get("tier", ""),
            "expires_at": data.get("expires_at", ""),
            "max_devices": data.get("max_devices", 1),
            "bound_device_id": device_id,
            "activated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "last_validated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        },
        "server_url": get_server_url()
    }

    _write_json(LICENSE_PATH, record)
    return record

def validate_with_server():
    existing = _read_json(LICENSE_PATH, {})
    license_key = existing.get("license_key", "")
    email = existing.get("license", {}).get("email", "")
    if not license_key or not email:
        raise RuntimeError("No activated license found")

    device_id = get_or_create_device_id()
    payload = {
        "email": email.strip().lower(),
        "license_key": license_key.strip(),
        "device_id": device_id,
        "hostname": _hostname(),
        "app_version": "v1"
    }

    data = _post_json(f"{get_server_url()}/validate-license", payload)

    existing.setdefault("license", {})
    existing["license"]["status"] = data.get("status", existing["license"].get("status", ""))
    existing["license"]["tier"] = data.get("tier", existing["license"].get("tier", ""))
    existing["license"]["expires_at"] = data.get("expires_at", existing["license"].get("expires_at", ""))
    existing["license"]["max_devices"] = data.get("max_devices", existing["license"].get("max_devices", 1))
    existing["license"]["bound_device_id"] = device_id
    existing["license"]["last_validated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    existing["server_url"] = get_server_url()
    _write_json(LICENSE_PATH, existing)
    return existing
