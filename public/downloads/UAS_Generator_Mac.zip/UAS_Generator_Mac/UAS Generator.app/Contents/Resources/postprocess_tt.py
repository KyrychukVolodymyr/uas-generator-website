import re
from pathlib import Path
from openpyxl import load_workbook


def sanitize_assessment_date_strict(value):
    """MAC_V20_PATCH4_STRICT_DATE_SANITIZE: keep only first MM/DD/YYYY and remove Finalized Date contamination."""
    text = str(value or "")
    m = re.search(r"\b\d{1,2}/\d{1,2}/\d{4}\b", text)
    return m.group(0) if m else text.replace("Finalized Date:", "").strip()

def patch_tt_date(xlsx_path: Path, assessment_date: str):
    """MAC_V20_PATCH4_TT_DATE_FOOTER_CLEAN: replace TT footer date and remove Finalized Date contamination."""
    wb = load_workbook(xlsx_path)
    clean_date = sanitize_assessment_date_strict(assessment_date)
    changed = False
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str):
                    value = cell.value
                    if value.strip().startswith("Date:") or "Finalized Date" in value:
                        cell.value = "Date: " + clean_date
                        changed = True
    if changed:
        wb.save(xlsx_path)
